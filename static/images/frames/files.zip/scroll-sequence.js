/* =========================================================
   AVENGINEERS — Scroll-scrubbed aircraft sequence
   Drives a 300-frame image sequence from scroll position,
   Apple-product-page style: pin the canvas, scrub frames
   as the user scrolls through the .scroll-scene track.
========================================================= */

(function () {
  const FRAME_COUNT = 300;
  const FRAME_PATH = (i) =>
    STATIC_FRAME_BASE + "frame-" + String(i).padStart(3, "0") + ".jpg";

  const canvas = document.getElementById("sequenceCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const scene = document.querySelector(".scroll-scene");
  const sceneContent = document.querySelector(".scene-content");
  const progressBar = document.querySelector(".scene-progress-bar");

  const images = new Array(FRAME_COUNT);
  let loadedCount = 0;
  let currentFrame = -1;
  let ready = false;

  const seq = { frame: 0 };

  function resizeCanvas() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = window.innerWidth * dpr;
    canvas.height = window.innerHeight * dpr;
    canvas.style.width = window.innerWidth + "px";
    canvas.style.height = window.innerHeight + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (ready) drawFrame(currentFrame === -1 ? 0 : currentFrame, true);
  }

  function drawFrame(index, force) {
    if (!force && index === currentFrame) return;
    const img = images[index];
    if (!img || !img.complete || img.naturalWidth === 0) return;
    currentFrame = index;

    const cw = window.innerWidth;
    const ch = window.innerHeight;
    const iw = img.naturalWidth;
    const ih = img.naturalHeight;

    // cover-fit
    const scale = Math.max(cw / iw, ch / ih);
    const dw = iw * scale;
    const dh = ih * scale;
    const dx = (cw - dw) / 2;
    const dy = (ch - dh) / 2;

    ctx.clearRect(0, 0, cw, ch);
    ctx.drawImage(img, dx, dy, dw, dh);
  }

  function preload() {
    for (let i = 1; i <= FRAME_COUNT; i++) {
      const img = new Image();
      img.src = FRAME_PATH(i);
      img.onload = () => {
        loadedCount++;
        if (i === 1) drawFrame(0, true);
        if (loadedCount === FRAME_COUNT) {
          ready = true;
          scene && scene.classList.add("sequence-ready");
        }
      };
      images[i - 1] = img;
    }
  }

  function onScroll() {
    if (!scene) return;
    const rect = scene.getBoundingClientRect();
    const sceneHeight = scene.offsetHeight - window.innerHeight;
    const scrolled = -rect.top;
    let progress = sceneHeight > 0 ? scrolled / sceneHeight : 0;
    progress = Math.max(0, Math.min(1, progress));

    const frameIndex = Math.min(
      FRAME_COUNT - 1,
      Math.floor(progress * (FRAME_COUNT - 1))
    );

    requestAnimationFrame(() => drawFrame(frameIndex, false));

    if (sceneContent) {
      // fade + lift the intro copy out over the first 22% of the scrub
      const introFade = 1 - Math.min(1, progress / 0.22);
      sceneContent.style.opacity = introFade;
      sceneContent.style.transform =
        "translate(-50%, calc(-50% + " + (1 - introFade) * -40 + "px))";
    }

    if (progressBar) {
      progressBar.style.width = progress * 100 + "%";
    }
  }

  window.addEventListener("resize", resizeCanvas);
  window.addEventListener("scroll", onScroll, { passive: true });

  resizeCanvas();
  preload();
  onScroll();
})();
